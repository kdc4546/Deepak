#include <xc.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define _XTAL_FREQ 8000000  // PIC18F4580 Crystal Frequency

#define BAUD_RATE 2400
//#define MY_UBRR F_CPU/16/BAUD_RATE-1

#define EEPROM_SIZE 1024  // Size of EEPROM memory

volatile uint8_t data_received = 0;
volatile uint16_t eeprom_address = 0;

void USART_Init(unsigned int ubrr) {
    // Set baud rate
    SPBRG = ubrr;
    SPBRGH = (ubrr >> 8);
    
    // Enable transmitter and receiver
    TXSTA = 0x24;  // TX enable, BRGH = 1
    RCSTA = 0x90;  // SPEN = 1, RX9 = 0
    BAUDCON = 0x08;  // BRG16 = 1
    
    // Enable interrupts
    PIE1bits.RCIE = 1;  // Enable USART Receive Interrupt
    INTCONbits.PEIE = 1;  // Enable Peripheral Interrupts
    INTCONbits.GIE = 1;  // Enable Global Interrupts
}

void USART_Transmit(unsigned char data) {
    while (!TXIF);
    TXREG = data;
}

unsigned char USART_Receive() {
    while (!RCIF);
    return RCREG;
}

void USART_Transmit_String(const char* str) {
    while (*str != '\0') {
        USART_Transmit(*str);
        str++;
    }
}

void __interrupt() ISR(void) {
    if (RCIF) {
        char received_byte = USART_Receive();
        
        // Store received byte in EEPROM
        if (eeprom_address < EEPROM_SIZE) {
            EEADR = eeprom_address;
            EEDATA = received_byte;
            EECON1bits.EEPGD = 0;
            EECON1bits.CFGS = 0;
            EECON1bits.WREN = 1;
            INTCONbits.GIE = 0;  // Disable interrupts
            EECON2 = 0x55;
            EECON2 = 0xAA;
            EECON1bits.WR = 1;
            INTCONbits.GIE = 1;  // Re-enable interrupts
            while (EECON1bits.WR);  // Wait for write to complete
            EECON1bits.WREN = 0;  // Disable write
            eeprom_address++;
        }
        
        // Check for end of transmission
        if (received_byte == '\0') {
            data_received = 1;
        }
    }
}

int main() {
    OSCCON = 0x72;  // Select internal oscillator block
    TRISCbits.RC7 = 1;  // RX pin as input
    TRISCbits.RC6 = 0;  // TX pin as output
    
    USART_Init(16/BAUD_RATE-1);
    
    while (!data_received) {
        // Wait for data to be fully received
    }
    
    // Send stored data back to PC
    for (uint16_t addr = 0; addr < eeprom_address; addr++) {
        EEADR = addr;
        EECON1bits.EEPGD = 0;
        EECON1bits.CFGS = 0;
        EECON1bits.RD = 1;
        while (EECON1bits.RD);
        USART_Transmit(EEDATA);
    }
    while (1) {
        // Main loop, data already sent back to PC
    }
    return 0;
}
